import pygame, sys, math, random
from pygame.locals import *

# Memulai pygame
pygame.init()

# Mengatur window yang digunakan untuk menampilkan demo
screen = pygame.display.set_mode((640, 480))

# pygame.time.Clock() digunakan untuk memberikan waktu animasi pada objek.
# Waktu yang diberikan akan disajikan dalam detik
clock = pygame.time.Clock()

# Membuat bentuk persegi dalam window untuk frame bola
player = pygame.Rect(15,15,15,15)

# vec dan direction pada awalnya di inisialisasi dengan none
vec = None
direction = None
target = 141, 250
while True:
    for event in pygame.event.get():
        # Apabila event diakhiri maka window juga akan keluar
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        
        # Apabila kursor diarahkan ke window maka program akan mendapatkan posisi koordinat
        if event.type == pygame.MOUSEBUTTONDOWN:
            target = pygame.mouse.get_pos()

    # currentx dan currenty diinisialisasi dengan player.x dan player.y
    # Digunakan sebagai variable untuk koordinat dari player
    currentx = player.x
    currenty = player.y

    # Mengatur posisi vector dibutuhkan koordinat dari posisi dari target dan player
    vec = (target[0] - currentx, target[1] - currenty)

    # Apabila sudah diketahui hasilnya maka nilai vector tersebut akan dimasukkan ke dalam rumus untuk mencari jarak
    distance = math.sqrt(vec[0]**2 + vec[1]**2)

    # Menampilkan jarak
    print(distance)

    # Apabila distance atau jaraknya 0 maka program tidak akan menampilkan direction maupun garis
    if(distance == 0):
        pass

    # Apabila terdapat distance maka program akan menampilkan garis dan koordinat yang dilewati garis
    else:
        normalize = (vec[0]/round(distance), vec[1]/round(distance))
        direction = normalize
        print(normalize) # Menampilkan keadaan normal
        print(direction) # Menampilkan koordinat yang dilewati oleh garis
        print(vec)       # Menampilkan vector
    
    speed_x = round(direction[0] * 5)
    speed_y = round(direction[1] * 5)

    player.x += speed_x
    player.y += speed_y

    # Menampilkan bentuk objek yang 
    pygame.draw.rect(screen, (0,255,0), player)

    # clock.tick(60) digunakan untuk meng-update waktu
    # Waktu yang digunakan untuk menganimasikan atau menggerakkan objek adalah 60 detik
    clock.tick(60)

    # pygame.display.update() digunakan untuk meng-update tampilan
    pygame.display.update()










